# My useful-pkg are consist of:
* foo.py - the simple module
* boo - the nested package with:
    * bar.py - the other simple module

And there are two other files:
* index.py - the main file which package is started from
* useful.py - another simple module for testing the import