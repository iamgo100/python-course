'''Module foo'''

def tools(s):
    return str(s)

__all__ = ['tools']