# My simple package are consist of:
* index.py - the main file
* useful.py - the first simple module
* useful_pkg - the first package with:
    * foo.py - the second simple module
    * boo - the second package with:
        * bar.py - the third simple module