'''Module bar'''

def b():
    return 'boobar'

__all__ = ['b']